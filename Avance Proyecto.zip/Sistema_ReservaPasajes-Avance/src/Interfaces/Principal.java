package Interfaces;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Interfaces.Login;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class Principal extends JFrame {

	int xMouse,yMouse;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	
	/**
	 * Create the frame.
	 */
	public Principal() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 393);
	    setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel button_exit = new JPanel();
		button_exit.addMouseListener(new MouseAdapter() {
			@Override
			//accion de cerrar
			public void mouseClicked(MouseEvent e) {
			System.exit(0);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				button_exit.setBackground(new Color(0, 165,190));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				button_exit.setBackground(new Color(27,31,94));
			}
		});
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Principal.class.getResource("/images/mundo (2).png")));
		lblNewLabel_1.setBounds(377, 309, 75, 73);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Principal.class.getResource("/images/logopequeño2.png")));
		lblNewLabel.setBounds(10, 0, 99, 87);
		contentPane.add(lblNewLabel);
		button_exit.setBackground(new Color(27, 31, 94));
		button_exit.setBounds(421, 0, 31, 27);
		contentPane.add(button_exit);
		
		JLabel exittxt = new JLabel("X");
		exittxt.setHorizontalAlignment(SwingConstants.CENTER);
		exittxt.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		exittxt.setForeground(new Color(255, 255, 255));
		exittxt.setFont(new Font("Roboto Light", Font.BOLD, 16));
		button_exit.add(exittxt);
		
		
		
		
		
		/*BOTON INICIAR SESION*/
		JPanel button_inicia = new JPanel();
		button_inicia.addMouseListener(new MouseAdapter() {
			///accion
			public void mouseClicked(MouseEvent e) {
				  Login loginFrame = new Login();
	                loginFrame.setVisible(true);
	                // (Opcional) Cerrar la ventana Principal
	                Principal.this.dispose();
	    
				}
			@Override
			public void mouseEntered(MouseEvent e) {
			button_inicia.setBackground(new Color(5,163,188));
			}
			
			public void mouseExited(MouseEvent e) {
				button_inicia.setBackground(new Color(27,31,94));
			}
		});
		
		
		
		
		button_inicia.setBackground(new Color(27, 31, 94));
		button_inicia.setBorder(null);
		button_inicia.setBounds(170, 219, 110, 27);
		contentPane.add(button_inicia);
		
		JLabel lblNewLabel_3 = new JLabel(" Iniciar sesión");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Roboto", Font.BOLD, 13));
		button_inicia.add(lblNewLabel_3);
		
		JLabel frase = new JLabel("\"Más que un vuelo, una experiencia única.\"");
		frase.setFont(new Font("Roboto", Font.ITALIC, 10));
		frase.setForeground(new Color(27, 31, 94));
		frase.setBackground(new Color(27, 31, 94));
		frase.setBounds(10, 368, 323, 25);
		contentPane.add(frase);
	
		
		
		
		
		
		
		
		/*BOTON REGISTRO */
		JPanel button_registro = new JPanel() ;
		button_registro.addMouseListener(new MouseAdapter() {
			//ACCION
			@Override
			public void mouseClicked(MouseEvent e) {
				  javax.swing.JOptionPane.showMessageDialog(null, "Registrar clickeado");
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				button_registro.setBackground(new Color(5,163,188));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				button_registro.setBackground(new Color(27,31,94));
			}
		});
		
		
		
		
		
		
		
		
		button_registro.setBorder(null);
		button_registro.setBackground(new Color(27, 31, 94));
		button_registro.setBounds(170, 271, 110, 27);
		contentPane.add(button_registro);
		
		JLabel lblNewLabel_3_1 = new JLabel("Regístrate");
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Roboto", Font.BOLD, 13));
		button_registro.add(lblNewLabel_3_1);
		
		JLabel user_logo = new JLabel("");
		user_logo.setBackground(new Color(255, 255, 255));
		user_logo.setIcon(new ImageIcon(Principal.class.getResource("/images/icons8-usuario-96 (4).png")));
		user_logo.setBounds(171, 80, 109, 144);
		contentPane.add(user_logo);
		
		JLabel Fondo = new JLabel("");
		Fondo.setIcon(new ImageIcon(Principal.class.getResource("/images/asas.png")));
		Fondo.setBounds(0, -23, 452, 435);
		contentPane.add(Fondo);
		
		// Registrar el mousePressed para obtener la posición inicial
        
		
		JPanel barra_inferior = new JPanel();
		
		/////////////// mejor movimiento de la ventana 
		barra_inferior.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
		
		barra_inferior.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
			
				    int x = e.getXOnScreen() ;
				    int y = e.getYOnScreen() ;
				    
				    // Mueve el componente a la nueva posición
				    Principal.this.setLocation(x-xMouse, y-yMouse);
			}
		});
		barra_inferior.setBounds(0, 0, 421, 27);
		contentPane.add(barra_inferior);
	}	
}
