package Logica;
import java.sql.*;
import javax.swing.JOptionPane;
public class Procesos extends Conexion {
	PreparedStatement pst; 
	Connection con;
	ResultSet res;

	public boolean validarUsuario(String usuario, String clave) {
        try {     
            con = Conexion.Conectar(con);  
            String consulta = "SELECT * FROM USUARIO WHERE user_name = '" + usuario 
            + "' AND contraseña = '" + clave + "';";
            pst = con.prepareStatement(consulta);
            res = pst.executeQuery();
            if (res.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "error");
            return false;
        } finally {
            try {
                if (res != null) res.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error finalizando recursos: " + e.toString());
            }
        }
	}
	public boolean emailRegistrado(String email) {
		try {
			con = Conexion.Conectar(con);
			String cheksql = "SELECT COUNT(*) FROM usuario WHERE email = ?";
			PreparedStatement checkStmt = con.prepareStatement(cheksql);
			checkStmt.setString(1, email);
			ResultSet res = checkStmt.executeQuery();
			res.next();
			return res.getInt(1) > 0;

		}catch(SQLException e1) {
			
		}
		return true;
	}
	public boolean registrarUsuario(String apellidos, String nombres, String usuario,
			String direccion, String nacionalidad, String telefono, String email, String contrasena) {
		try {
			con = Conexion.Conectar(con);
			String sql = "INSERT INTO usuario(apellidos, nombres, usuario, direccion, nacionalidad, telefon, email, contraseña)"
					+ "VALUES (?,?,?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1,apellidos);
			pst.setString(2, nombres);
			pst.setString(3, usuario);
			pst.setString(4, direccion);
			pst.setString(5, nacionalidad);
			pst.setString(6, telefono);
			pst.setString(7, email);
			pst.setString(8, contrasena);
			int resultado = pst.executeUpdate();
			return resultado > 0;
		} catch(SQLException e2) {
			
		}
		return true;
	}
	
}
	
